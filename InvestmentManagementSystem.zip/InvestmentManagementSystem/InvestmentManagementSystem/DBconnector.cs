﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InvestmentManagementSystem
{
    class DBconnector
    {
        public static String CONNECTION_STRING = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\sapch\\source\\repos\\InvestmentManagementSystem\\InvestmentManagementSystem\\investmentdb.mdf;Integrated Security = True";
    }
}
